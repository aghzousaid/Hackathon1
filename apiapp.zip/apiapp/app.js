const express = require('express')
const app = new express()

let trajets = []

trajets.push({
    // "Heure départ":"17h20",
    // "Heure arrivé":"17h23",
    "départ": "Nation",
    "arrivée": "Chatelet",
    "id":""},
    {
    "départ": "Auber",
    "arrivée": "Versaille",
    "id":1
    },
    {
    "départ": "Sartrouville",
    "arrivée": "Gare de Lyon",
    "id":2
    },
    {
    "départ": "La Defense",
    "arrivée": "Suresnes",
    "id":3
    },
    {
    "départ": "Le Blanc Mesnil",
    "arrivée": "Stade de France",
    "id":4
    }
)

app.get('/recherche', function (req, res) {
    let reponse = {
        "Status": "Je suis en marche"
    }
    res.json(reponse)
})

app.get('/', function (req, res) {
    let reponse = {
        "Status": "Je suis en marche"
    }
    res.json(reponse)
})
app.get('/trajets', function (req, res) {

    res.json(trajets)
})
app.get('/trajets/ajouter/:depart/:arrivee', function (req, res) {
    trajets.push({
        "départ":req.params.depart,
        "arrivée":req.params.arrivee
    })
    res.json("OK")
})
app.get('/trajets/:id', function (req, res) {

    res.json(reponse)
})

app.get('/trajets/ajouter/Accompagnant/:id/:prenom/:nom', function (req, res) {
    // trajets.push({
    //     "départ":req.params.depart,
    //     "arrivée":req.params.arrivee
    // })
    // res.json("OK")

    res(trajets.keys)
})

app.listen(3000, () => console.log('Example app listening on port 3000!'))